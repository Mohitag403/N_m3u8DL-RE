﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_m3u8DL_RE.Parser.Constants
{
    internal class DASHTags
    {
        public static string TemplateRepresentationID = "$RepresentationID$";
        public static string TemplateBandwidth = "$Bandwidth$";
        public static string TemplateNumber = "$Number$";
        public static string TemplateTime = "$Time$";
    }
}
