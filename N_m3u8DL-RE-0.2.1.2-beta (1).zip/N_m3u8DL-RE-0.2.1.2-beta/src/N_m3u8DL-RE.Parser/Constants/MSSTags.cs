﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_m3u8DL_RE.Parser.Constants
{
    internal class MSSTags
    {
        public static string Bitrate = "{Bitrate}";
        public static string Bitrate_BK = "{bitrate}";
        public static string StartTime = "{start_time}";
        public static string StartTime_BK = "{start time}";
    }
}
