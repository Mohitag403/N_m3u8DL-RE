﻿namespace N_m3u8DL_RE.Common.Enum
{
    public enum RoleType
    {
        Subtitle = 0,
        Main = 1,
        Alternate = 2,
        Supplementary = 3,
        Commentary = 4,
        Dub = 5,
        Description = 6,
        Sign = 7,
        Metadata = 8,
    }
}
